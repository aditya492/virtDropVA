export default {
  items: [
    {
      name: 'VA Applications',      
      icon: 'fa fa-file-o',
      url: '/admin/va-application',
    },
  ]
};