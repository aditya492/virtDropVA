export default {
  items: [
    {
      name: 'VA Requests',
      url: '/admin/va-request',
      icon: 'fa fa-list',
    },
    {
      name: 'Discovery Call',      
      icon: 'fa fa-calendar-o',
      url: '/admin/scheduled-booking',
    },
    {
      name: 'VA Applications',      
      icon: 'fa fa-file-o',
      url: '/admin/va-application',
    }  
  ],
};
