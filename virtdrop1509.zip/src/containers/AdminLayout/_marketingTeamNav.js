export default {
  items: [
    {
      name: 'Discovery Call',      
      icon: 'fa fa-calendar-o',
      url: '/admin/scheduled-booking',
    },
    {
      name: 'eBook Downloads',      
      icon: 'fa fa-book',
      url: '/admin/newsletter',
    },  
  ]
};